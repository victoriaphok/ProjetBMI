package com.example.bmiinsight;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface BodyDAO {
    @Insert
    void insertAll(Body...bodies);
    @Update
    void updateAll(Body...bodies);
    @Delete
    void delete(Body...bodies);
    @Query("Select * from Body")
    List<Body> getAll();
}
