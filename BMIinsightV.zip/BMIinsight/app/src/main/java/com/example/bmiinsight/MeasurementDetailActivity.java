package com.example.bmiinsight;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class MeasurementDetailActivity extends AppCompatActivity {

    Button calculButton;
    Button historyButton;
    EditText weightEditText;
    EditText heightEditText;
    TextView resultTextView;
    TextView explicationTextView;
    Spinner weightSpinner;
    Spinner heightSpinner;
    List<String> weightSpinnerArray;
    ArrayAdapter<String> weightAdapter;
    List<String> heightSpinnerArray;
    ArrayAdapter<String> heightAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_measurement_detail);
        Singleton.getInstance().createDatabase(MeasurementDetailActivity.this);

        calculButton = findViewById(R.id.calculButton);
        historyButton=findViewById(R.id.historyButton);
        weightEditText=findViewById(R.id.weightEditText);
        heightEditText=findViewById(R.id.heightEditText);
        resultTextView =findViewById(R.id.resultTextView);
        explicationTextView=findViewById(R.id.explicationTextView);
        weightSpinner=findViewById(R.id.weightSpinner);
        heightSpinner=findViewById(R.id.heightSpinner);
        DecimalFormat df = new DecimalFormat("0.00");

//-------------------------------------------Spinners----------------------------------------------
        //---------------------------1-------------------------------
        // Create a list of items for the spinner weight.
        weightSpinnerArray = new ArrayList<>();
        weightSpinnerArray.add("Kilograms");
        weightSpinnerArray.add("Pounds");

        // Create an ArrayAdapter using the string array and a default spinner layout
        weightAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, weightSpinnerArray);

        // Specify the layout to use when the list of choices appears
        weightAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // Apply the adapter to the spinner
        weightSpinner.setAdapter(weightAdapter);

        //------------------------2--------------------------------
        // Create a list of items for the spinner height.
        heightSpinnerArray = new ArrayList<>();
        heightSpinnerArray.add("meter");
        heightSpinnerArray.add("inch");

        // Create an ArrayAdapter using the string array and a default spinner layout
        heightAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, heightSpinnerArray);

        // Specify the layout to use when the list of choices appears
        heightAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // Apply the adapter to the spinner
        heightSpinner.setAdapter(heightAdapter);

//-----------------------------------------------------------------------------------------------
        calculButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text1 = weightSpinner.getSelectedItem().toString();
                String text2 = heightSpinner.getSelectedItem().toString();
                double weight = Double.parseDouble(weightEditText.getText().toString());
                double height = Double.parseDouble(heightEditText.getText().toString());

                double calcul;
                double poids = 0;
                double taille = 0;

                if (text1.equals("Pounds")) {
                    poids = weight / 2.205;
                } else {
                    poids = weight;
                }
                if (text2.equals("inch")) {
                    taille = height / 39.37;

                } else {
                    taille = height;
                }
                calcul = poids / (taille * taille);
                String resultat = df.format(calcul);
                resultTextView.setText("Resultat : " + resultat + " % BMI");
                if (calcul <= 18.50) {
                    explicationTextView.setText("Meaning : you are in the Thinness category ");
                } else if (calcul > 18.50 && calcul <= 25) {
                    explicationTextView.setText("Meaning : you are in the Normal category ");
                } else if (calcul > 25 && calcul <= 30) {
                    explicationTextView.setText("Meaning : you are in the Overweight category");
                } else if (calcul > 30 && calcul <= 40) {
                    explicationTextView.setText("Meaning : you are in the Moderate Obesity category");
                } else if (calcul > 40) {
                    explicationTextView.setText("Meaning : you are in the Severe Obesity category");
                }
                if (Singleton.getInstance().itemSelected == -1) {
                    Body b = new Body();
                    b.weight = Double.parseDouble(weightEditText.getText().toString());
                    b.height = Double.parseDouble(heightEditText.getText().toString());
                    Singleton.getInstance().addBody(b);
                } else {
                    Body b = Singleton.getInstance().getBodies().get(Singleton.getInstance().itemSelected);
                    b.weight = Double.parseDouble(weightEditText.getText().toString());
                    b.height = Double.parseDouble(heightEditText.getText().toString());
                    Singleton.getInstance().updateBody(b);


                }

                if (Singleton.getInstance().itemSelected >= 0) {
                    Body b = Singleton.getInstance().getBodies().get(Singleton.getInstance().itemSelected);
                    weightEditText.setText(String.valueOf(b.weight));
                    heightEditText.setText(String.valueOf(b.height));
                }


            }



        });
        historyButton.setOnClickListener(view -> {
            Intent intent = new Intent(MeasurementDetailActivity.this, HistoricalDataActivity.class);
            startActivity(intent);
        });
    };

}



