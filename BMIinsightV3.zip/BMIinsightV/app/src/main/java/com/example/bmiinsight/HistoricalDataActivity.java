package com.example.bmiinsight;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class HistoricalDataActivity extends AppCompatActivity {
    RecyclerView mainRecyclerView;
    Button addButton;
    BodyArrayAdapter adapter = new BodyArrayAdapter();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historical_data);

        Singleton.getInstance().createDatabase(HistoricalDataActivity.this);


        mainRecyclerView = findViewById(R.id.mainRecyclerView);
        addButton = findViewById(R.id.addButton);
        mainRecyclerView.setAdapter(adapter);
        mainRecyclerView.setLayoutManager(new LinearLayoutManager(HistoricalDataActivity.this));

        addButton.setOnClickListener(View -> {
            Singleton.getInstance().itemSelected = -1;
            Intent intent = new Intent(HistoricalDataActivity.this,MeasurementDetailActivity.class);
            startActivity(intent);
        });

        adapter.setClickListener(new BodyArrayAdapter.ItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Singleton.getInstance().itemSelected = position;
                Intent intent = new Intent(HistoricalDataActivity.this, MeasurementDetailActivity.class);
                startActivity(intent);

            }

            @Override
            public void onItemLongClick(View view, int position) {
                Singleton.getInstance().deleteBody(position);
                adapter.notifyItemRemoved(position);

            }

        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        adapter.notifyDataSetChanged();
        //nouvel item se montre sur l'écran
    }
}
