package com.example.bmiinsight;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button calculButton;
        Button historicalButton;

        calculButton = findViewById(R.id.calculButton);
        historicalButton = findViewById(R.id.historicalButton);

        calculButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this,MeasurementDetailActivity.class);
            startActivity(intent);
        });

        historicalButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, HistoricalDataActivity.class);
            startActivity(intent);
        });

    }
}