package com.example.bmiinsight;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.text.DateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Date;

@Entity
public class Body {
    @PrimaryKey(autoGenerate = true)
    public int uid;
    @ColumnInfo
    public double percent;
    @ColumnInfo
    public Date date;
    @ColumnInfo
    public double weight;
    @ColumnInfo
    public double height;


}
