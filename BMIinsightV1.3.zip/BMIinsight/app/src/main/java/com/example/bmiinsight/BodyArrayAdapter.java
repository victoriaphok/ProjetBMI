package com.example.bmiinsight;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class BodyArrayAdapter extends RecyclerView.Adapter<BodyArrayAdapter.ViewHolder> {
    //hold the items
    public interface ItemClickListener{
        void onItemClick(View view, int position);
        void onItemLongClick(View view, int position);
    }
    private ItemClickListener clickListener;

    public void setClickListener(ItemClickListener clickListener){
        this.clickListener = clickListener;
    }
    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView textView1;
        TextView textView2;
        public ViewHolder(View itemView){
            super(itemView);
            //hold information from the 2 textview
            textView1 = itemView.findViewById(R.id.bmi_percent);
            textView2 = itemView.findViewById(R.id.date_time);
            itemView.setOnClickListener(view -> {
                if(clickListener != null){
                    clickListener.onItemClick(view,getAdapterPosition());
                }
            });
            itemView.setOnLongClickListener(view -> {
                if(clickListener != null){
                    clickListener.onItemLongClick(view,getAdapterPosition());
                    return true;
                }
                return false;
            });
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //so the items can fit on the screen(scroll peut etre)
        Context context = parent.getContext();
        //more permission, new viewitem
        LayoutInflater inflater = LayoutInflater.from(context);
        View itemView = inflater.inflate(R.layout.item_recycler_view,parent,false);
        return new ViewHolder(itemView);

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        //bind the information from layout to the items
        Body b = Singleton.getInstance().getBodies().get(position);
        holder.textView1.setText(String.valueOf(b.percent));
        holder.textView2.setText(String.valueOf(b.date));

    }

    @Override
    public int getItemCount() {
        return Singleton.getInstance().getBodies().size();
    }
}
