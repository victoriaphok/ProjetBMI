package com.example.bmiinsight;

import android.content.Context;

import java.util.List;

public class Singleton {
    private static Singleton instance = new Singleton();
    private Singleton(){}
    public static Singleton getInstance() {
        return instance;
    }

    public int itemSelected = -1;
    BodyDAO bodyDAO;
    public void createDatabase(Context context){
        bodyDAO = AppDatabase.getInstance(context).bodyDAO();

    }
    public List<Body> getBodies(){
        return bodyDAO.getAll();
    }
    public void addProduct(Body b){
        bodyDAO.insertAll(b);

    }
    public void updateProduct(Body b){
        bodyDAO.updateAll(b);
    }
    public void deleteBody(int index){
        Body b = getBodies().get(index);
        bodyDAO.delete(b);
    }
}