package com.example.mybodymassindex;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class MeasureDetailActivity extends AppCompatActivity {
    EditText weightEditText;
    EditText heightEditText;
    Button saveButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_measure_detail);

        weightEditText = findViewById(R.id.weightEditText);
        heightEditText=findViewById(R.id.heightEditText);
        saveButton = findViewById(R.id.saveButton);

        saveButton.setOnClickListener(view -> {
            Bmi mesure = new Bmi(Integer.parseInt(heightEditText.getText().toString()),Integer.parseInt(weightEditText.getText().toString()));
            Singleton.getInstance().bmi.add(mesure);
            finish();
        });

    }
}