package com.example.mybodymassindex;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;

public class Bmi {
    public double height;
    public double weight;
    public double pourcentage;
    public LocalDateTime date;
    public Bmi(double height, double weight) {
        this.height = height;
        this.weight = weight;
        this.pourcentage = weight/((height/100)*(height/100));
        //SimpleDateFormat s = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        date = LocalDateTime.now();
    }
}
