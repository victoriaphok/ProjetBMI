package com.example.mybodymassindex;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    RecyclerView mainRecyclerView;
    Button addButton;
    BmiArrayAdapter adapter = new BmiArrayAdapter();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mainRecyclerView =findViewById(R.id.mainRecyclerView);
        addButton = findViewById(R.id.addButton);
        mainRecyclerView.setAdapter(adapter);
        mainRecyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));

        addButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this,MeasureDetailActivity.class);
            startActivity(intent);
        });
    }
}